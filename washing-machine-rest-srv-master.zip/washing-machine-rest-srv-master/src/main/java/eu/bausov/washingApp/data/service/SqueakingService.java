package eu.bausov.washing_machine_rest_srv.data.service;

import eu.bausov.washing_machine_rest_srv.domain.program.process.Squeaking;

/**
 * for saving the sqeaking process.
 */
public interface SqueakingService {
    Squeaking save(Squeaking squeaking);
}
