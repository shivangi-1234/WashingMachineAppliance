package eu.bausov.washing_machine_rest_srv.data.service;

import eu.bausov.washing_machine_rest_srv.domain.WashingMachine;

/**
 * for saving the washing machine appliance.
 */
public interface WashingMachineService {
    WashingMachine getFirst();
    WashingMachine save(WashingMachine washingMachine);
}
