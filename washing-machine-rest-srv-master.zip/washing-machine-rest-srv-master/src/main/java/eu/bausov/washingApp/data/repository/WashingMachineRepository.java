package eu.bausov.washing_machine_rest_srv.data.repository;

import eu.bausov.washing_machine_rest_srv.domain.WashingMachine;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * for the washing machine appliance.
 */
public interface WashingMachineRepository extends CrudRepository<WashingMachine, Long> {
    List<WashingMachine> findAll();
    WashingMachine save(WashingMachine appliance);
}
