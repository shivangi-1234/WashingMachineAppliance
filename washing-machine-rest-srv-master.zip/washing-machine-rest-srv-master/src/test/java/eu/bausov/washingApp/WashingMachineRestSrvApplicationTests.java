package eu.bausov.washing_machine_rest_srv;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class WashingMachineRestSrvApplicationTests {

	@Test
	public void contextLoads() {
	}

}
